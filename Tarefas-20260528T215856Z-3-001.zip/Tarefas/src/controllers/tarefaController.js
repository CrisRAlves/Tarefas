const tarefaModel = require('../models/tarefaModel');

// Listar
exports.listarTarefas = (req,res) => {
    const tarefas = tarefaModel.listar();
    res.json(tarefas);
};

// Criar
