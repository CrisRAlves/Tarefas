console.log("INICIO DO SERVIDOR");

const express = require('express');

const app = express();

app.use(express.json())

const PORT = 3000;

const tarefasRoutes = require('./src/routes/tarefasRoutes');

app.use('/api', tarefasRoutes);

app.get('/', (req,res) => {
    res.send('API de Tarefas funcionando')
});
